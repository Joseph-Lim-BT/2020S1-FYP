
from flask import Flask, request, jsonify, render_template,make_response
import os
import dialogflow
import requests
import json
import sqlite3
from sqlite3 import Error
from google.api_core.exceptions import InvalidArgument

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/webhook', methods=['POST','GET'])
def webhook():

    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'private_key.json'

    DIALOGFLOW_PROJECT_ID = 'customer-service-chatbot-new-o'
    #GOOGLE_APPLICATION_CREDENTIALS=b51ffc36cce45d0776cde6f7dd33bb771580830f77369344d9692789107326bfc85b341ebc3ff392
    DIALOGFLOW_LANGUAGE_CODE = 'en'
    SESSION_ID = 'me'


    req = request.get_json(silent=True, force=True)
    text_to_be_analyzed = req["queryResult"]["queryText"]


    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(DIALOGFLOW_PROJECT_ID, SESSION_ID)
    text_input = dialogflow.types.TextInput(text=text_to_be_analyzed, language_code=DIALOGFLOW_LANGUAGE_CODE)
    query_input = dialogflow.types.QueryInput(text=text_input)
   
   
    response = session_client.detect_intent(session=session, query_input=query_input)


def wind_direction(self, date=None, date_time=None):
        
        urlForWindDirection = "https://api.data.gov.sg/v1/environment/wind-direction" + date + "T" + hour + "%3A" + minute + "%3A" + second + "%2B08%3A00"
        if date:
            params['date'] = date
        if date_time:
            params['date_time'] = date_time
        return self.get('environment/wind-direction', params)

def wind_speed(self, date=None, date_time=None):
        urlForWindDirection = "https://api.data.gov.sg/v1/environment/wind-direction" + date + "T" + hour + "%3A" + minute + "%3A" + second + "%2B08%3A00"
        apiWindDirection = requests.get(urlForWindDirection)
        windDirectionJSON = apiWindDirection

        windItems = wind["items"]
        windInfo = windItems[0]['info']
        windDirection = windInfo['windinfo']
        windDirection = windDirection[strareaJSON.lower()]

        params = {}
        if date:
            params['date'] = date
        if date_time:
            params['date_time'] = date_time
        return self.get('environment/wind-speed', params)

def wind_speed(self, date=None, date_time=None):
        urlForWindSpeed = "https://api.data.gov.sg/v1/environment/wind-speed" + date + "T" + hour + "%3A" + minute + "%3A" + second + "%2B08%3A00"
        apiWindSpeed = requests.get(urlForWindSpeed)
        windSpeedJSON = apiWindSpeed

        windItems = wind["items"]
        windInfo = windItems[0]['info']
        windSpeed = windInfo['windinfo']
        windSpeed = windSpeed[strareaJSON.lower()]
        
        params = {}
        if date:
            params['date'] = date
        if date_time:
            params['date_time'] = date_time
        return self.get('environment/wind-speed', params)

def get_projectname(data):
    response = "The Wind Speed and Wind Direction for the region are" 
    reply = {
        "fulfillmentText": " " ,
        "fulfillmentMessages" : [
            {
              "text" : {
                  "text" : [response]
              }    
            }
        ]
    }    
    return jsonify(reply)    

if __name__ == '__main__':
    port = int(os.getenv('PORT', 80))
    app.run(port=port, host = '0.0.0.0')

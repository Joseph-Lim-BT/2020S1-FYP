
from flask import Flask, request, jsonify, render_template,make_response
import os
import dialogflow
import requests
import json
import sqlite3
from sqlite3 import Error
from google.api_core.exceptions import InvalidArgument

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/webhook', methods=['POST','GET'])
def webhook():

    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'private_key.json'

    DIALOGFLOW_PROJECT_ID = 'customer-service-chatbot-new-o'
    GOOGLE_APPLICATION_CREDENTIALS=b51ffc36cce45d0776cde6f7dd33bb771580830f77369344d9692789107326bfc85b341ebc3ff392
    DIALOGFLOW_LANGUAGE_CODE = 'en'
    SESSION_ID = 'me'


    req = request.get_json(silent=True, force=True)
    text_to_be_analyzed = req["queryResult"]["queryText"]


    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(DIALOGFLOW_PROJECT_ID, SESSION_ID)
    text_input = dialogflow.types.TextInput(text=text_to_be_analyzed, language_code=DIALOGFLOW_LANGUAGE_CODE)
    query_input = dialogflow.types.QueryInput(text=text_input)
   
   
    response = session_client.detect_intent(session=session, query_input=query_input)


    datetimeJSON = req["queryResult"]["parameters"]["datetime"]
    strdatetimeJSON = str(datetimeJSON)

    current = datetime.datetime.now()
    hour = ""
    if(len(str(current.hour)) == 1):
        hour = "0" + str(current.hour)
    else:
        hour = str(current.hour)

    date = str(current.date())
    minute = str(current.minute)
    second = str(current.second)

    urlForWindDirection = "https://api.data.gov.sg/v1/environment/wind-direction" + date + "T" + hour + "%3A" + minute + "%3A" + second + "%2B08%3A00"
    urlForWindSpeed = "https://api.data.gov.sg/v1/environment/wind-speed" + date + "T" + hour + "%3A" + minute + "%3A" + second + "%2B08%3A00"
    apiWindDirection = requests.get(urlForWindDirection)
    apiWindSpeed = requests.get(urlForWindSpeed)

    windDirectionJSON = apiWindDirection
    windSpeedJSON = apiWindSpeed

    windItems = wind["items"]
    windInfo = windItems[0]['info']
    windDirection = windInfo['windinfo']
    windDirection = windDirection[strlocationJSON.lower()]


def get_projectname(data):
    response = "The Wind Speed and Wind Direction for the region are" 
    reply = {
        "fulfillmentText": " " ,
        "fulfillmentMessages" : [
            {
              "text" : {
                  "text" : [response]
              }    
            }
        ]
    }    
    return jsonify(reply)    


if __name__ == "__main__":
    app.run()

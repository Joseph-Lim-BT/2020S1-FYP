import os
import dialogflow
import json
from urllib.request import Request
import requests
import datetime 
import ast
from flask import Flask
from flask import request
from flask import make_response
from google.api_core.exceptions import InvalidArgument

app = Flask(__name__)


@app.route('/webhook', methods=['POST','GET'])
def webhook():

    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'private_key.json'

    DIALOGFLOW_PROJECT_ID = 'customer-service-chatbot-new-o'
    DIALOGFLOW_LANGUAGE_CODE = 'en'
    SESSION_ID = 'me'


    req = request.get_json(silent=True, force=True)
    text_to_be_analyzed = req["queryResult"]["queryText"]


    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(DIALOGFLOW_PROJECT_ID, SESSION_ID)
    text_input = dialogflow.types.TextInput(text=text_to_be_analyzed, language_code=DIALOGFLOW_LANGUAGE_CODE)
    query_input = dialogflow.types.QueryInput(text=text_input)
   
   
    response = session_client.detect_intent(session=session, query_input=query_input)

    locationJSON = req["queryResult"]["parameters"]["Location"]
    strlocationJSON = str(locationJSON)

    currentDate = datetime.datetime.now()
    hourString = ""
    if(len(str(currentDate.hour)) == 1):
        hourString = "0" + str(currentDate.hour)
    else:
        hourString = str(currentDate.hour)

    dateString = str(currentDate.date())
    minString = str(currentDate.minute)
    secString = str(currentDate.second)
    
    urlToOpenPSI = "https://api.data.gov.sg/v1/environment/psi?date_time=" + dateString + "T" + hourString + "%3A" + minString + "%3A" + secString + "%2B08%3A00"
   
    urlToOpenPM25 = "https://api.data.gov.sg/v1/environment/pm25?date_time=" + dateString + "T" + hourString + "%3A" + minString + "%3A" + secString + "%2B08%3A00"
    
    apiResponsePSI = requests.get(urlToOpenPSI)
    apiResponsePM25 = requests.get(urlToOpenPM25)

    PSIjson = apiResponsePSI.text
    PSI = ast.literal_eval(PSIjson)
    PM25json = apiResponsePM25.text
    PM25 = ast.literal_eval(PM25json)



   
    psiItems = PSI["items"]
    psiReadings = psiItems[0]['readings']
    psi24hr = psiReadings['psi_twenty_four_hourly']
    psiRead = psi24hr[strlocationJSON.lower()]

    if(int(psiRead) > 300):
        airQual = "Hazardous"
    elif(int(psiRead) > 200):
        airQual = "Very unhealthy"
    elif(int(psiRead) > 100):
        airQual = "Unhealthy"
    elif(int(psiRead) > 50):
        airQual = "Moderate"
    else:
        airQual = "Good"
        
       
    pm25Read = PM25['items'][0]['readings']['pm25_one_hourly'][strlocationJSON.lower()]

    if(int(pm25Read) > 250):
        desriptor = "Very High"
    elif(int(pm25Read) > 150):
        descriptor = "High"
    elif(int(pm25Read) > 55):
        descriptor = "Elevated"
    else:
        descriptor = "Normal"


    
    #Building fulfillment text
    speech = "The Readings for the region " + strlocationJSON + " are:\n" + "24Hr PSI: " + str(psiRead) + " (" + airQual + ") \nPM2.5 Hourly: " + str(pm25Read) + "(" + descriptor + ")"

    res = {
        "fulfillmentText": " " ,
        "fulfillmentMessages" : [
            {
              "text" : {
                  "text" : [speech]
              }
            }
        ]
    }

    res = json.dumps(res, indent=4)
    print(str(res))
    r = make_response(res)
    r.headers['Content-Type'] = 'application/json'
    return r
    

if __name__ == '__main__':
    port = int(os.getenv('PORT', 80))
    #print ("Starting app on port %d" %(port))
    app.run(port=port, host = 'localhost')

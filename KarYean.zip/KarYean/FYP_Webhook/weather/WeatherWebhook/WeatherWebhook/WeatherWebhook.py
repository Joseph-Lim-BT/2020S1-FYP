import os
import dialogflow
import json
from urllib.request import Request
import requests
import datetime 
import ast
from flask import request
from flask import Flask
from google.api_core.exceptions import InvalidArgument

app = Flask(__name__)

@app.route('/webhook', methods=['POST','GET'])
def webhook():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'private_key.json'

    DIALOGFLOW_PROJECT_ID = 'customer-service-chatbot-new-o'
    DIALOGFLOW_LANGUAGE_CODE = 'en'
    SESSION_ID = 'me'

    req = request.get_json(silent = True, force = True)
    text_to_be_analyzed = req["queryResult"]["queryText"]
    #text_to_be_analyzed = req.get('queryResult').get('queryText')

    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(DIALOGFLOW_PROJECT_ID, SESSION_ID)
    text_input = dialogflow.types.TextInput(text=text_to_be_analyzed, language_code=DIALOGFLOW_LANGUAGE_CODE)
    query_input = dialogflow.types.QueryInput(text=text_input)
    
    response = session_client.detect_intent(session=session, query_input=query_input)

    AreaJSON = req["queryResult"]["parameters"]["Area"]
    #ForecastJSON = req["queryResult"]["parameters"]["Forecast"]
    strAreaJSON = str(AreaJSON)
    #strForecastJSON = str(ForecastJSON)

    currentDate = datetime.datetime.now()
    hourStr = ""
    if(len(str(currentDate.hour)) == 1):
        hourStr = "0" + str(currentDate.hour)
    else:
        hourStr = str(currentDate.hour)

    dateStr = str(currentDate.date())
    minStr = str(currentDate.minute)
    secStr = str(currentDate.second)
    
    urlToOpenWeather = "https://api.data.gov.sg/v1/environment/2-hour-weather-forecast?date_time=" + dateStr + "T" + hourStr + "%3A" + minStr + "%3A" + secStr + "%2B08%3A00"
    apiResponseWeather = requests.get(urlToOpenWeather)

    #convert str to dictionary
    json_weather = apiResponseWeather.text
    weather = ast.literal_eval(json_weather)

    WeatherItems = weather["items"]
    WeatherForecasts = WeatherItems[0]['forecasts']
    WeatherView = WeatherForecasts[(strAreaJSON)]
    #WeatherView = WeatherForecasts[(strWeatherJSON)]
    

    speech = "The Weather Forecast for " + strAreaJSON + " is:\n" + str(WeatherView)
    res = {
        "fulfillmentText": " " ,
        "fulfillmentMessages" : [
            {
              "text" : {
                  "text" : [speech]
              }
            }
        ]
    }

    #Create the json to return it to the dialogflow
    res = json.dumps(res, indent=3)
    r = make_response(res)
    r.headers['Content-Type'] = 'application/json'
    return r
    

if __name__ == '__main__':
    port = int(os.getenv('PORT', 80))
    print ("Starting app on port %d" %(port))
    app.run(port=port, host = 'localhost', debug=True)
    #app.run(host = 'localhost', port = 80)
    # This is required to run Flask
import os
import dialogflow
import json
from urllib.request import urlopen, Request
import requests
import datetime 
from flask import Flask
from flask import request
from flask import make_response
from google.api_core.exceptions import InvalidArgument


app= Flask(__name__)


@app.route('/webhook', methods=['POST','GET'])

def webhook():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'private_key.json'
    DIALOGFLOW_PROJECT_ID = 'customer-service-chatbot-new-o'
    DIALOGFLOW_LANGUAGE_CODE = 'en'
    SESSION_ID = 'me'

    text_to_be_analyzed = "Status of uv"

    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(DIALOGFLOW_PROJECT_ID, SESSION_ID)
    text_input = dialogflow.types.TextInput(text=text_to_be_analyzed, language_code=DIALOGFLOW_LANGUAGE_CODE)
    query_input = dialogflow.types.QueryInput(text=text_input)

    try:
        responses = session_client.detect_intent(session=session, query_input=query_input)
        
    except InvalidArgument:
        raise


    date = datetime.datetime.now()
    hourStr = ""
    if(len(str(date.hour)) == 1):
        hourStr = "0" + str(date.hour)
    else:
        hourStr = str(date.hour)    

    dateStr = str(date.date())
    minStr = str(date.minute)
    secStr = str(date.second)
    dateFormat = str(dateStr + "T" + hourStr + "%3A" + minStr + "%3A" + secStr)

    uvURL = "https://api.data.gov.sg/v1/environment/uv-index?date_time=" + dateFormat
    responseuvURL= urlopen(uvURL)
    dataUV = responseuvURL.read().decode("utf-8")
    apiDataUV = json.loads(dataUV)

    print(json.dumps(apiDataUV, indent=4))

    try:
        info = apiDataUV["api_info"]
        uvStatus = info["status"]
        item = apiDataUV["items"]
        uvIndex = item[0]['index']
        uvValue = uvIndex[0]['value']
    except KeyError:
        print("error")

    speech = "The value for the ultraviolet as of " + str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))+ " is "+ str(uvValue) +".\nThe status of the index is " + str(uvStatus)

    
    res = {
        "fulfillmentText":" ",
        "fulfillmentMessages":[
            {
                "text":{
                    "text" :[speech]
                    }
                }
            ]
        }
    res = json.dumps(res, indent=4)
    r = make_response(res)
    r.headers['Content-Type'] = 'application/json'
    return r

    

if __name__ == '__main__':
    port = int(os.getenv('PORT', 80))
    print ("Starting app on port %d" %(port))
    app.run(port=port, host = 'localhost')

    #REMARKS: this version of code is trying to retrieve information from API and post it into the dialogflow but error occured while it post
    # However, it is able to run and tunnel on http 80. 
import datetime
import json
from urllib.request import urlopen, Request
import requests

date = datetime.datetime.now()
hourStr = ""
if(len(str(date.hour)) == 1):
    hourStr = "0" + str(date.hour)
else:
    hourStr = str(date.hour)

dateStr = str(date.date())
minStr = str(date.minute)
secStr = str(date.second)
dateFormat = str(dateStr + "T" + hourStr + "%3A" + minStr + "%3A" + secStr)

uvURL = "https://api.data.gov.sg/v1/environment/uv-index?"
responseuvURL= urlopen(uvURL)
dataUV = responseuvURL.read().decode("utf-8")
apiDataUV = json.loads(dataUV)

print(json.dumps(apiDataUV, indent=4))


info = apiDataUV["api_info"]
uvStatus = info["status"]
item = apiDataUV["items"]
uvIndex = item[0]['index']
uvValue = uvIndex[0]['value']

text = "The value for the ultraviolet as of " + str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))+ " is "+ str(uvValue) +".\nThe status of the index is " + str(uvStatus)
print(text)

#this code is for testing purposes in terminal itself. Trying to retrieve information from API and it works